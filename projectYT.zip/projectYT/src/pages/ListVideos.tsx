import { VideoItem } from "@/components/VideoItem";
import { videos } from "@/constants";
import { Categories } from "@/layouts/components/Categories";

const ListVideos = () => {
  return (
    <div>
      <Categories className="sticky top-[56px] z-10 mx-5 overflow-x-auto bg-background" />
      <div className="m-5 my-0 mt-3 grid grid-cols-4 gap-4">
        {videos.map((video) => (
          <VideoItem
            key={video.id}
            thumbnail={video.thumbnail}
            title={video.title}
            channelId={video.channelId}
            id={video.id}
            avatar={video.avatar}
            channelTitle={video.channelTitle}
            viewCount={video.viewCount}
            duration={video.duration}
            publishedAt={video.publishedAt}
          />
        ))}
      </div>
    </div>
  );
};

export default ListVideos;
