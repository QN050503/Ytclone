import {
  AlignJustifyIcon,
  BellIcon,
  CameraIcon,
  MicIcon,
  YoutubeIcon,
} from "@/components/icon";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

interface HeaderProps {
  onClick: () => void;
}

export const Header = ({ onClick }: HeaderProps) => {
  return (
    <nav className="fixed top-0 z-10 flex w-full items-center justify-between bg-background px-5 py-2">
      <div className="flex items-center gap-4">
        <div onClick={onClick}>
          <AlignJustifyIcon className="icon" />
        </div>
        <Link to="/">
          <YoutubeIcon />
        </Link>
      </div>
      <div className="flex items-center gap-2">
        <Input placeholder="Tìm kiếm" className="w-[550px]" />
        <MicIcon className={cn("icon", "bg-white/10 hover:bg-white/20")} />
      </div>
      <div className="flex items-center gap-2">
        <CameraIcon className="icon" />
        <Badge count={100}>
          <BellIcon className="icon" />
        </Badge>
        <Avatar className="ml-2">
          <AvatarImage src="https://lh3.googleusercontent.com/a/ACg8ocI-ANweFu2tNdY8eqic_0tC1CQ9FrhBaQQNcxVldQki6KQ63yKS=s360-c-no" />
          <AvatarFallback>D</AvatarFallback>
        </Avatar>
      </div>
    </nav>
  );
};
