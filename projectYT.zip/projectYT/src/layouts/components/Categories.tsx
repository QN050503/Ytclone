import { categories } from "@/constants";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

interface CategoriesProps {
  className?: string;
}

export const Categories = ({ className }: CategoriesProps) => {
  return (
    <div
      className={cn(
        "flex min-h-14 items-center gap-3 overflow-x-auto",
        className,
      )}
    >
      {categories.map((category) => (
        <Link
          className={cn("category", {
            "bg-white text-black": category.isActive,
          })}
          key={category.title}
          to={category.url}
        >
          {category.title}
        </Link>
      ))}
    </div>
  );
};
