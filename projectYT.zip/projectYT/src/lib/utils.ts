import { twMerge } from "tailwind-merge";
import { clsx, type ClassValue } from "clsx";
import { parse, toSeconds } from "iso8601-duration";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function convertISO8601ToHHMMSS(duration: string) {
  // Parse ISO 8601 duration
  const parsed = parse(duration);

  // Chuyển đổi sang tổng số giây
  const totalSeconds = toSeconds(parsed);

  // Tính giờ, phút, giây
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  // Định dạng HH:MM:SS
  return [
    hours.toString().padStart(2, "0"),
    minutes.toString().padStart(2, "0"),
    seconds.toString().padStart(2, "0"),
  ].join(":");
}

export function formatViewCount(views: number) {
  if (views >= 1_000_000) {
    return (
      new Intl.NumberFormat("en-US", {
        notation: "compact",
        maximumFractionDigits: 1,
      }).format(views) + " views"
    );
  }
  return new Intl.NumberFormat("en-US").format(views) + " views";
}
