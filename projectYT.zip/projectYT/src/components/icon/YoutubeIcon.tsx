export const YoutubeIcon = () => {
  return (
    <div className="flex items-center gap-1">
      <img src="/youtube-logo.svg" alt="Logo youtube" className="h-7" />
      <span className="text-lg font-medium">Premium</span>
    </div>
  );
};
