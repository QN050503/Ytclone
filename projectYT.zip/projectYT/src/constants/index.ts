export const categories = [
  {
    title: "Tất cả",
    url: "#",
    isActive: true,
  },
  {
    title: "Âm nhạc",
    url: "#",
    isActive: false,
  },
  {
    title: "Danh sách kết hợp",
    url: "#",
    isActive: false,
  },
  {
    title: "Trực tiếp",
    url: "#",
    isActive: false,
  },
  {
    title: "Trò chơi",
    url: "#",
    isActive: false,
  },
  {
    title: "Mới tải lên gần đây",
    url: "#",
    isActive: false,
  },
  {
    title: "Đã xem",
    url: "#",
    isActive: false,
  },
  {
    title: "Đề xuất mới",
    url: "#",
    isActive: false,
  },
];

export const videos = [
  {
    id: "XdM9Iz57lvw",
    channelId: "UC7_YxT-KID8kRbqZo7MyscQ",
    thumbnail:
      "https://i.ytimg.com/vi/YEsn8VzT1vw/hq720.jpg?sqp=-oaymwEnCNAFEJQDSFryq4qpAxkIARUAAIhCGAHYAQHiAQoIGBACGAY4AUAB&rs=AOn4CLBcJltrafMBlH5QMRqoJPlwbA5Fsw",
    avatar:
      "https://yt3.ggpht.com/41323YpPTdLUASqkQAQUC7DqsW681rPwaU87pHoRX1gv1NSDf3OMT6GY_0FskBX_ZpyKc_69gw=s68-c-k-c0x00ffffff-no-rj",
    title: "Cách làm việc năng suât",
    channelTitle: "Markiplier",
    viewCount: 2941859,
    duration: "PT10M31S",
    publishedAt: "2025-01-13T20:51:25Z",
  },
  {
    id: "XdM9Iz57lvw",
    channelId: "UCa6vGFO9ty8v5KZJXQxdhaw",
    thumbnail: "https://i.ytimg.com/vi/XdM9Iz57lvw/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/ytc/AIdro_nSCPp4CpBWkdd80box-lGFHhnfwo6Q3FV_br-SY1IibyFX=s160-c-k-c0x00ffffff-no-rj",
    title: "Jimmy Kimmel Returns During the Los Angeles Wildfires",
    channelTitle: "Jimmy Kimmel Live",
    viewCount: 2085839,
    duration: "PT15M36S",
    publishedAt: "2025-01-14T04:45:01Z",
  },
  {
    id: "fg1cnoaxIvs",
    channelId: "UCZ3AmknSJtbzXCeO5a4peoQ",
    thumbnail: "https://i.ytimg.com/vi/fg1cnoaxIvs/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/ytc/AIdro_mFmvmkc9_gMKYep5K7gyWExAC4W32orA1OIMsq5w6nWq8=s160-c-k-c0x00ffffff-no-rj",
    title: "I CHEATED In Squid Games",
    channelTitle: "LazarLazar",
    viewCount: 2051772,
    duration: "PT11M38S",
    publishedAt: "2025-01-14T08:08:17Z",
  },
  {
    id: "1agk_MfSoQM",
    channelId: "UC7_YxT-KID8kRbqZo7MyscQ",
    thumbnail: "https://i.ytimg.com/vi/1agk_MfSoQM/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/ytc/AIdro_nfDvwu14-iN5YZcaLIomwno1_3oFcYTmG5_kn7SMj_nec=s160-c-k-c0x00ffffff-no-rj",
    title: "I Was Evacuated from the LA Fires",
    channelTitle: "Markiplier",
    viewCount: 3661990,
    duration: "PT10M31S",
    publishedAt: "2025-01-13T20:51:25Z",
  },
  {
    id: "A6nKtw4W8wA",
    channelId: "UCIDbIn1BZAQg74rj_IlgwhA",
    thumbnail: "https://i.ytimg.com/vi/A6nKtw4W8wA/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/Ob4JY3XcwRfdu2uO5SvYMsRxrXaWv50OJ9PFfbQaea99PSlDWw39qD570JS-WuoNRtlzeNeAskU=s160-c-k-c0x00ffffff-no-rj",
    title:
      "CAM'RON SOUNDS OFF ON JIM JONES, NFL PLAYOFFS & GELO GOT THE SONG OF THE YEAR?! | S6 EP1",
    channelTitle: "Come And Talk 2 Me",
    viewCount: 1165405,
    duration: "PT1H18M15S",
    publishedAt: "2025-01-13T13:00:17Z",
  },
  {
    id: "vybLi25Q8Fw",
    channelId: "UC8-Th83bH_thdKZDJCrn88g",
    thumbnail: "https://i.ytimg.com/vi/vybLi25Q8Fw/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/rNNmF5XK6SpfwhSL2Uf-GFiezejcbhfRYax6qTG0wQNHbBldm3YyQ6HLY6Ps4YweUNvXQGvUCg=s160-c-k-c0x00ffffff-no-rj",
    title:
      "Linus Sebastian Shows Jimmy and Bad Bunny Some Mind-Blowing Technology (Extended) | The Tonight Show",
    channelTitle: "The Tonight Show Starring Jimmy Fallon",
    viewCount: 1414353,
    duration: "PT8M46S",
    publishedAt: "2025-01-14T05:25:00Z",
  },
  {
    id: "vyNLi2hQ8Fw",
    channelId: "UC8-Th83bH_thdcbnsJCrn88g",
    thumbnail: "https://i.ytimg.com/vi/Av9C7xlV0fA/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/kub0rXGIpWKXcfe9F_jQmutFzojSZWR7TA2GneW2dbnefqUEVC7msiDdZFuAsGM22Le3Vv-2=s160-c-k-c0x00ffffff-no-rj",
    title:
      "Build a Jira Clone With Nextjs, React, Tailwind, Hono.js | Part 1/2 (2024)",
    channelTitle: "Code With Antonio",
    viewCount: 373592,
    duration: "PT8H45M26S",
    publishedAt: "2024-12-14T05:25:00Z",
  },
  {
    id: "Nsbi2hdh3Fw",
    channelId: "UC8-Th8wncH_thdcbndJCrn88g",
    thumbnail: "https://i.ytimg.com/vi/gedoSfZvBgE/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/HjXKmDGoAp6b-JdGYpqJYYeN4S_CMpD_kqWvldpN53cbzn-i73t6mVNo8mNki-xLPwi0BVSFi-o=s160-c-k-c0x00ffffff-no-rj",
    title: "Lợi ích của một giấc ngủ ngon - Shai Marcu",
    channelTitle: "TED-Ed",
    viewCount: 6783583,
    duration: "PT5M44S",
    publishedAt: "2014-01-14T05:25:00Z",
  },
  {
    id: "Nsbi2hQ8Fw",
    channelId: "UC8-Th83bH_thdcbnsJCrn88g",
    thumbnail: "https://i.ytimg.com/vi/pRybm9lXW2c/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/kub0rXGIpWKXcfe9F_jQmutFzojSZWR7TA2GneW2dbnefqUEVC7msiDdZFuAsGM22Le3Vv-2=s160-c-k-c0x00ffffff-no-rj",
    title:
      "Fullstack Trello Clone: Next.js 14, Server Actions, React, Prisma, Stripe, Tailwind, MySQL",
    channelTitle: "Code With Antonio",
    viewCount: 329592,
    duration: "PT11H54M26S",
    publishedAt: "2024-01-14T05:25:00Z",
  },
  {
    id: "Nsbi2hasnf3Fw",
    channelId: "UC8-Th8wncH_thdcbndJCrn88g",
    thumbnail: "https://i.ytimg.com/vi/qH0tUg4Enn0/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/HjXKmDGoAp6b-JdGYpqJYYeN4S_CMpD_kqWvldpN53cbzn-i73t6mVNo8mNki-xLPwi0BVSFi-o=s160-c-k-c0x00ffffff-no-rj",
    title: "The dark history of arsenic - Neil Bradbury",
    channelTitle: "TED-Ed",
    viewCount: 267835,
    duration: "PT6M29S",
    publishedAt: "2025-01-10T05:25:00Z",
  },
  {
    id: "snhi2hasnf3Fw",
    channelId: "UC8-Th8wncH_thdcbancCrn88g",
    thumbnail: "https://i.ytimg.com/vi/6mteqO61BP4/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/5rZUq5BsQ7TFG_4-JGFbtjd33JnKfsFFJ9ZDT6ZsUqRwevk1hFSIuPlxl9inmLlZGOHRKcS6=s160-c-k-c0x00ffffff-no-rj",
    title: "ASMR - Building an List box using Reactjs and Tailwindcss",
    channelTitle: "Komaster",
    viewCount: 611093,
    duration: "PT1H04M26S",
    publishedAt: "2024-01-10T05:25:00Z",
  },
  {
    id: "snhi2hxnvnf3Fw",
    channelId: "UC8-Th8wncH_thdcbancCrn88g",
    thumbnail: "https://i.ytimg.com/vi/2E5edr4_LXw/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/5rZUq5BsQ7TFG_4-JGFbtjd33JnKfsFFJ9ZDT6ZsUqRwevk1hFSIuPlxl9inmLlZGOHRKcS6=s160-c-k-c0x00ffffff-no-rj",
    title: "ASMR Coding - Building a notebook using Tauri and ReactJS",
    channelTitle: "Komaster",
    viewCount: 3439,
    duration: "PT44M29S",
    publishedAt: "2023-01-10T05:25:00Z",
  },
  {
    id: "snhi2snc452nf3Fw",
    channelId: "UC8-Th8wncH_thdcbancCrhe937",
    thumbnail: "https://i.ytimg.com/vi/2LRLsMracAY/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/2gIM9Fqo_8CRFvhJk8C_ALpyY6ShpNedIsc4HweHWg_XX171jEURHUC8lYt9CLUqrWTDj8FSiA=s160-c-k-c0x00ffffff-no-rj",
    title:
      "Build Advanced MERN Auth: 2FA, Email Verification, Cookies, Sessions, and JWT with Node.js & Next.js",
    channelTitle: "TechWithEmma",
    viewCount: 26094,
    duration: "PT9H30M26S",
    publishedAt: "2024-12-10T05:25:00Z",
  },
  {
    id: "snhi2cbns52nf3Fw",
    channelId: "UC8-Th8wncH_thdcbancCrhe937",
    thumbnail: "https://i.ytimg.com/vi/H6K4TjKI_AU/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/2gIM9Fqo_8CRFvhJk8C_ALpyY6ShpNedIsc4HweHWg_XX171jEURHUC8lYt9CLUqrWTDj8FSiA=s160-c-k-c0x00ffffff-no-rj",
    title:
      "Zustand FULL COURSE in 2024 | Simple React/NextJS Redux Alternative",
    channelTitle: "TechWithEmma",
    viewCount: 930482,
    duration: "PT1H30M26S",
    publishedAt: "2024-08-10T05:25:00Z",
  },
  {
    id: "snhi2csnchrnf3Fw",
    channelId: "UC8-Th8wncH_thdc475hdrhe937",
    thumbnail: "https://i.ytimg.com/vi/6UmM3nSX7Wo/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/ytc/AIdro_ndYTK3vtsDFSJ3rjTaKmmvLwcqJpKGQn2yHd5M-iI2Ayyb=s160-c-k-c0x00ffffff-no-rj",
    title: "Thế Giới Màu Nhiệm của Tranh Nhân Quả",
    channelTitle: "tiến nam",
    viewCount: 166935,
    duration: "PT40M29S",
    publishedAt: "2024-11-10T05:25:00Z",
  },
  {
    id: "sndnxrt4nf3Fw",
    channelId: "UC8-Th8wncH_thdc475hdrhe937",
    thumbnail: "https://i.ytimg.com/vi/Omc74EZeIWg/maxresdefault.jpg",
    avatar:
      "https://yt3.googleusercontent.com/ytc/AIdro_ndYTK3vtsDFSJ3rjTaKmmvLwcqJpKGQn2yHd5M-iI2Ayyb=s160-c-k-c0x00ffffff-no-rj",
    title: "GIẢI MÃ GIA ĐÌNH NALA",
    channelTitle: "tiến nam",
    viewCount: 706935,
    duration: "PT1H36M26S",
    publishedAt: "2024-07-10T05:25:00Z",
  },
];
