import { convertISO8601ToHHMMSS, formatViewCount } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import moment from "moment";

interface VideoItemProps {
  id: string;
  channelId: string;
  thumbnail: string;
  avatar: string;
  title: string;
  channelTitle: string;
  viewCount: number;
  duration: string;
  publishedAt: string;
}

export const VideoItem = ({
  id,
  channelId,
  thumbnail,
  avatar,
  title,
  channelTitle,
  viewCount,
  duration,
  publishedAt,
}: VideoItemProps) => {
  return (
    <div className="">
      <div className="relative">
        <img src={thumbnail} alt={title} className="rounded-md" />
        <span className="absolute bottom-2 right-2 rounded-sm bg-black/40 px-1 py-[2px] text-xs">
          {convertISO8601ToHHMMSS(duration)}
        </span>
      </div>
      <div className="my-2 flex items-start gap-3">
        <Avatar>
          <AvatarImage src={avatar} />
          <AvatarFallback>N</AvatarFallback>
        </Avatar>
        <div className="">
          <h1 className="font-medium">
            {title.length > 30 ? title.slice(0, 47) + "..." : title}
          </h1>
          <p className="text-sm text-muted-foreground">{channelTitle}</p>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <span>{formatViewCount(viewCount)}</span>
            <span>•</span>
            <span>{moment(publishedAt).fromNow()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
