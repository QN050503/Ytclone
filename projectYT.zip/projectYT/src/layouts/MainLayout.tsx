import { Outlet } from "react-router-dom";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";

import { useLocalStorage } from "usehooks-ts";
import { cn } from "@/lib/utils";
import { MobileSidebar } from "./components/MobileSidebar";

const MainLayout = () => {
  const [isOpen, setIsOpen] = useLocalStorage("sidebar-open", true);

  const toggleSidebar = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <main className="min-h-screen">
      <Header onClick={toggleSidebar} />
      <div
        className={cn("", {
          "grid grid-cols-[250px_1fr]": isOpen,
          "grid grid-cols-[120px_1fr]": !isOpen,
        })}
      >
        {isOpen ? <Sidebar /> : <MobileSidebar />}
        <div className="mt-[56px]">
          <Outlet />
        </div>
      </div>
    </main>
  );
};

export default MainLayout;
